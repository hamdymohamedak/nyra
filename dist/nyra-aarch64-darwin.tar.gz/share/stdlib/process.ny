import "vec_str.ny"

extern fn command_run_argv(program: string, args: ptr) -> i32

struct Command {
    program: string
    args: StrVec
}

fn Command_new(program: string) -> Command {
    return Command { program: program, args: StrVec_new() }
}

impl Command {
    fn arg(self, value: string) -> Command {
        return Command {
            program: self.program,
            args: self.args.push(value),
        }
    }

    fn run(self) -> i32 {
        return command_run_argv(self.program, StrVec_raw(self.args))
    }
}

struct Process {
    pid: i32
}

fn Process_new(pid: i32) -> Process {
    return Process { pid: pid }
}

fn run_command(program: string) -> i32 {
    let args = StrVec_new()
    return command_run_argv(program, StrVec_raw(args))
}

fn command_run_args(program: string, args: StrVec) -> i32 {
    return command_run_argv(program, StrVec_raw(args))
}
