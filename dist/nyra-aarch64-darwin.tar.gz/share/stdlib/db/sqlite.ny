// SQLite — requires `link sqlite3` in nyra.mod when using this module.

struct SqliteDb {
    handle: ptr
}

extern fn sqlite_open(path: string) -> ptr
extern fn sqlite_exec(handle: ptr, sql: string) -> i32
extern fn sqlite_close(handle: ptr) -> void

fn Sqlite_open(path: string) -> SqliteDb {
    return SqliteDb { handle: sqlite_open(path) }
}

impl SqliteDb {
    fn exec(self, sql: string) -> i32 {
        return sqlite_exec(self.handle, sql)
    }

    fn close(self) -> void {
        sqlite_close(self.handle)
    }

    fn query(self, sql: string) -> string {
        let rc = self.exec(sql)
        if rc != 0 {
            return ""
        }
        return "ok"
    }
}
