extern fn channel_new() -> ptr
extern fn channel_send(ch: ptr, value: i32) -> void
extern fn channel_recv(ch: ptr) -> i32
extern fn channel_free(ch: ptr) -> void

struct Channel_i32 {
    handle: ptr
}

fn Channel_i32_new() -> Channel_i32 {
    return Channel_i32 { handle: channel_new() }
}

impl Channel_i32 {
    fn send(self, value: i32) -> Channel_i32 {
        channel_send(self.handle, value)
        return Channel_i32 { handle: self.handle }
    }

    fn recv(self) -> i32 {
        return channel_recv(self.handle)
    }
}

impl Drop for Channel_i32 {
    fn drop(self) -> void {
        channel_free(self.handle)
    }
}
