import "syscall.ny"

struct TcpListener {
    fd: i32
}

struct TcpStream {
    fd: i32
}

fn tcp_listen(host: string, port: i32) -> TcpListener {
    let fd = sys_listen(host, port)
    return TcpListener { fd: fd }
}

fn tcp_accept(listener: TcpListener) -> TcpStream {
    let fd = sys_accept(listener.fd)
    return TcpStream { fd: fd }
}

fn tcp_connect(host: string, port: i32) -> TcpStream {
    let fd = sys_connect(host, port)
    return TcpStream { fd: fd }
}

fn tcp_read(stream: TcpStream, max_bytes: i32) -> string {
    return sys_recv(stream.fd, max_bytes)
}

fn tcp_write(stream: TcpStream, data: string) -> i32 {
    return sys_send(stream.fd, data)
}

fn tcp_close_stream(stream: TcpStream) -> void {
    sys_close(stream.fd)
}

fn tcp_close_listener(listener: TcpListener) -> void {
    sys_close(listener.fd)
}
