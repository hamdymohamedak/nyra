import "../../strings.ny"
import "types.ny"

fn method_from_line(line: string) -> i32 {
    if strlen(line) < 3 {
        return 0
    }
    if strcmp(substring(line, 0, 3), "GET") == 0 {
        return METHOD_GET
    }
    if strlen(line) >= 4 {
        if strcmp(substring(line, 0, 4), "POST") == 0 {
            return METHOD_POST
        }
        if strcmp(substring(line, 0, 4), "HEAD") == 0 {
            return METHOD_HEAD
        }
    }
    if strlen(line) >= 3 {
        if strcmp(substring(line, 0, 3), "PUT") == 0 {
            return METHOD_PUT
        }
    }
    if strlen(line) >= 6 {
        if strcmp(substring(line, 0, 6), "DELETE") == 0 {
            return METHOD_DELETE
        }
    }
    if strlen(line) >= 7 {
        if strcmp(substring(line, 0, 7), "OPTIONS") == 0 {
            return METHOD_OPTIONS
        }
    }
    if strlen(line) >= 5 {
        if strcmp(substring(line, 0, 5), "PATCH") == 0 {
            return METHOD_PATCH
        }
    }
    return 0
}

fn path_from_line(line: string) -> string {
    let sp1 = strstr_pos(line, " ")
    if sp1 < 0 {
        return "/"
    }
    let start = sp1 + 1
    let rest = substring(line, start, strlen(line) - start)
    let sp2 = strstr_pos(rest, " ")
    if sp2 < 0 {
        return rest
    }
    let path_q = substring(rest, 0, sp2)
    let q = strstr_pos(path_q, "?")
    if q < 0 {
        return path_q
    }
    return substring(path_q, 0, q)
}

fn query_from_line(line: string) -> string {
    let sp1 = strstr_pos(line, " ")
    if sp1 < 0 {
        return ""
    }
    let start = sp1 + 1
    let rest = substring(line, start, strlen(line) - start)
    let sp2 = strstr_pos(rest, " ")
    if sp2 < 0 {
        return ""
    }
    let path_q = substring(rest, 0, sp2)
    let q = strstr_pos(path_q, "?")
    if q < 0 {
        return ""
    }
    return substring(path_q, q + 1, strlen(path_q) - (q + 1))
}

fn first_line(raw: string) -> string {
    let nl = strstr_pos(raw, "\r\n")
    if nl < 0 {
        return raw
    }
    return substring(raw, 0, nl)
}

fn body_from_raw(raw: string) -> string {
    let sep = strstr_pos(raw, "\r\n\r\n")
    if sep < 0 {
        return ""
    }
    return substring(raw, sep + 4, strlen(raw) - (sep + 4))
}

fn method_name(method: i32) -> string {
    if method == METHOD_GET { return "GET" }
    if method == METHOD_POST { return "POST" }
    if method == METHOD_PUT { return "PUT" }
    if method == METHOD_DELETE { return "DELETE" }
    if method == METHOD_PATCH { return "PATCH" }
    if method == METHOD_HEAD { return "HEAD" }
    if method == METHOD_OPTIONS { return "OPTIONS" }
    return "GET"
}

fn RequestContext_from_raw(raw: string) -> RequestContext {
    let line = first_line(raw)
    return RequestContext {
        method: method_from_line(line),
        path: path_from_line(line),
        body: body_from_raw(raw),
        query: query_from_line(line),
        raw: raw,
    }
}

fn route_key(method: i32, path: string) -> string {
    let m = method_name(method)
    let prefix = strcat(m, ":")
    return strcat(prefix, path)
}
