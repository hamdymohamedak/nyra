import "../net/tcp.ny"

extern fn ws_connect(url: string) -> i32
extern fn ws_send_text(fd: i32, text: string) -> i32
extern fn ws_recv_text(fd: i32, max_bytes: i32) -> string
extern fn ws_close(fd: i32) -> void

struct WebSocket {
    fd: i32
}

fn WebSocket_connect(url: string) -> WebSocket {
    // Supports ws:// and wss:// (TLS when OpenSSL is available at link time).
    let fd = ws_connect(url)
    return WebSocket { fd: fd }
}

impl WebSocket {
    fn send(self, text: string) -> i32 {
        return ws_send_text(self.fd, text)
    }

    fn recv(self, max_bytes: i32) -> string {
        return ws_recv_text(self.fd, max_bytes)
    }

    fn close(self) -> void {
        ws_close(self.fd)
    }
}
