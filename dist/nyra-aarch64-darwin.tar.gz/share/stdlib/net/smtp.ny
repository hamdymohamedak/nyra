import "../net/tcp.ny"
import "../strings.ny"

fn smtp_send_line(stream: TcpStream, line: string) -> void {
    let msg = strcat(strcat(line, "\r\n"), "")
    tcp_write(stream, msg)
}

fn smtp_expect_ok(stream: TcpStream) -> i32 {
    let resp = tcp_read(stream, 512)
    if strlen(resp) < 3 {
        return -1
    }
    if char_at(resp, 0) == 50 || char_at(resp, 0) == 51 {
        return 0
    }
    return -1
}

fn Smtp_send(host: string, port: i32, from: string, to: string, body: string) -> i32 {
    let stream = tcp_connect(host, port)
    if stream.fd < 0 {
        return -1
    }
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, strcat("EHLO ", host))
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, strcat("MAIL FROM:<", strcat(from, ">")))
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, strcat("RCPT TO:<", strcat(to, ">")))
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, "DATA")
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, body)
    smtp_send_line(stream, ".")
    if smtp_expect_ok(stream) != 0 {
        tcp_close_stream(stream)
        return -1
    }
    smtp_send_line(stream, "QUIT")
    tcp_close_stream(stream)
    return 0
}
