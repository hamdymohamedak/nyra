// Built-in memory helpers (implemented in nyra_rt.c).
// Use without import — same as `print` and `time_start`.
//
//   mem_start("alloc")
//   // ... code to measure
//   mem_end("alloc")   // RSS delta in B/KB/MB (green in terminal)

extern fn mem_start(label: string) -> void
extern fn mem_end(label: string) -> void
