struct HashMap_str_i32 {
    handle: ptr
}

extern fn map_str_i32_new() -> ptr
extern fn map_str_i32_insert(m: ptr, key: string, value: i32) -> void
extern fn map_str_i32_get(m: ptr, key: string) -> i32
extern fn map_str_i32_contains(m: ptr, key: string) -> i32
extern fn map_str_i32_free(m: ptr) -> void

fn HashMap_str_i32_new() -> HashMap_str_i32 {
    return HashMap_str_i32 { handle: map_str_i32_new() }
}

impl HashMap_str_i32 {
    fn insert(self, key: string, value: i32) -> HashMap_str_i32 {
        map_str_i32_insert(self.handle, key, value)
        return HashMap_str_i32 { handle: self.handle }
    }

    fn get(self, key: string) -> i32 {
        return map_str_i32_get(self.handle, key)
    }

    fn contains(self, key: string) -> i32 {
        return map_str_i32_contains(self.handle, key)
    }
}

impl Drop for HashMap_str_i32 {
    fn drop(self) -> void {
        map_str_i32_free(self.handle)
    }
}


struct HashMap_str_str {
    handle: ptr
}

extern fn map_str_str_new() -> ptr
extern fn map_str_str_insert(m: ptr, key: string, value: string) -> void
extern fn map_str_str_get(m: ptr, key: string) -> string
extern fn map_str_str_contains(m: ptr, key: string) -> i32
extern fn map_str_str_free(m: ptr) -> void

fn HashMap_str_str_new() -> HashMap_str_str {
    let handle = map_str_str_new()
    return HashMap_str_str { handle: handle }
}

impl HashMap_str_str {
    fn insert(self, key: string, value: string) -> HashMap_str_str {
        map_str_str_insert(self.handle, key, value)
        return HashMap_str_str { handle: self.handle }
    }

    fn get(self, key: string) -> string {
        return map_str_str_get(self.handle, key)
    }

    fn contains(self, key: string) -> i32 {
        return map_str_str_contains(self.handle, key)
    }
}

impl Drop for HashMap_str_str {
    fn drop(self) -> void {
        map_str_str_free(self.handle)
    }
}
