// TLS — OpenSSL-backed HTTPS client + server (linked when OpenSSL is available).
extern fn tls_available() -> i32
extern fn rt_tls_connect(host: string, port: i32) -> i32
extern fn rt_tls_read(handle: i32, max_bytes: i32) -> string
extern fn rt_tls_write(handle: i32, data: string) -> i32
extern fn rt_tls_close(handle: i32) -> void
extern fn rt_tls_listen(cert_path: string, key_path: string, host: string, port: i32) -> i32
extern fn rt_tls_accept(listener: i32) -> i32
extern fn rt_tls_listener_close(listener: i32) -> void

fn tls_connect(host: string, port: i32) -> i32 {
    return rt_tls_connect(host, port)
}

fn tls_read(handle: i32, max_bytes: i32) -> string {
    return rt_tls_read(handle, max_bytes)
}

fn tls_write(handle: i32, data: string) -> i32 {
    return rt_tls_write(handle, data)
}

fn tls_close(handle: i32) -> void {
    rt_tls_close(handle)
}

fn tls_ready() -> bool {
    return tls_available() != 0
}

fn tls_listen(cert_path: string, key_path: string, host: string, port: i32) -> i32 {
    return rt_tls_listen(cert_path, key_path, host, port)
}

fn tls_accept(listener: i32) -> i32 {
    return rt_tls_accept(listener)
}

fn tls_listener_close(listener: i32) -> void {
    rt_tls_listener_close(listener)
}
