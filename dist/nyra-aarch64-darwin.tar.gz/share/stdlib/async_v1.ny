// Async runtime v1 — thin wrappers over rt_async.c (RFC 0005).

extern fn async_promise_new() -> i32
extern fn async_promise_complete(handle: i32, value: i32) -> void
extern fn async_await(handle: i32) -> i32
extern fn async_poll(handle: i32) -> i32
extern fn runtime_run() -> void

struct Promise_i32 {
    handle: i32
}

fn Promise_new_i32() -> Promise_i32 {
    let h = async_promise_new()
    return Promise_i32 { handle: h }
}

fn Promise_complete_i32(p: Promise_i32, value: i32) -> void {
    async_promise_complete(p.handle, value)
}

fn Promise_await_i32(p: Promise_i32) -> i32 {
    return await p.handle
}

fn Executor_poll_once() -> void {
    runtime_run()
}
