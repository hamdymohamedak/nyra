extern fn json_get_string(json: string, key: string) -> string
