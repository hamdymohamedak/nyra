#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <windows.h>
extern void nyra_winsock_ensure(void);

typedef struct {
    int done;
    int result;
    CRITICAL_SECTION cs;
    CONDITION_VARIABLE cv;
} NyraTask;

static CRITICAL_SECTION g_table_cs;
static int g_table_init = 0;

static void table_lock_init(void) {
    if (!g_table_init) {
        InitializeCriticalSection(&g_table_cs);
        g_table_init = 1;
    }
}

#define TASK_LOCK(t) EnterCriticalSection(&(t)->cs)
#define TASK_UNLOCK(t) LeaveCriticalSection(&(t)->cs)
#define TASK_WAIT(t) \
    while (!(t)->done) { \
        SleepConditionVariableCS(&(t)->cv, &(t)->cs, INFINITE); \
    }
#define TASK_SIGNAL(t) WakeAllConditionVariable(&(t)->cv)
#define TASK_INIT(t) \
    InitializeCriticalSection(&(t)->cs); \
    InitializeConditionVariable(&(t)->cv)

#define IO_LOCK() EnterCriticalSection(&g_io_cs)
#define IO_UNLOCK() LeaveCriticalSection(&g_io_cs)

static CRITICAL_SECTION g_io_cs;
static int g_io_cs_init = 0;

static void io_lock_init(void) {
    if (!g_io_cs_init) {
        InitializeCriticalSection(&g_io_cs);
        g_io_cs_init = 1;
    }
}

#else
#include <pthread.h>

#ifdef __APPLE__
#include <sys/event.h>
#include <sys/time.h>
#elif defined(__linux__)
#include <sys/epoll.h>
#endif

typedef struct {
    int done;
    int result;
    pthread_mutex_t mu;
    pthread_cond_t cv;
} NyraTask;

static pthread_mutex_t g_table_mu = PTHREAD_MUTEX_INITIALIZER;

#define TASK_LOCK(t) pthread_mutex_lock(&(t)->mu)
#define TASK_UNLOCK(t) pthread_mutex_unlock(&(t)->mu)
#define TASK_WAIT(t) \
    while (!(t)->done) { \
        pthread_cond_wait(&(t)->cv, &(t)->mu); \
    }
#define TASK_SIGNAL(t) pthread_cond_broadcast(&(t)->cv)
#define TASK_INIT(t) \
    pthread_mutex_init(&(t)->mu, NULL); \
    pthread_cond_init(&(t)->cv, NULL)

#define IO_LOCK() pthread_mutex_lock(&g_io_mu)
#define IO_UNLOCK() pthread_mutex_unlock(&g_io_mu)

#endif

int spawn_capture(void (*body)(void *), void *data, long long nbytes);
int io_wait_once(int timeout_ms);

#define NYRA_MAX_TASKS 4096

static NyraTask *g_tasks[NYRA_MAX_TASKS];
static int g_next_task = 1;

#ifdef __APPLE__
static int g_kq = -1;
static pthread_mutex_t g_io_mu = PTHREAD_MUTEX_INITIALIZER;
#elif defined(__linux__)
static int g_epoll = -1;
static pthread_mutex_t g_io_mu = PTHREAD_MUTEX_INITIALIZER;
#elif defined(_WIN32)
#define NYRA_MAX_IO 64
static struct {
    int fd;
    int task_id;
    int active;
} g_io_tab[NYRA_MAX_IO];
static int g_io_n = 0;
#endif

static NyraTask *task_get(int id) {
    if (id <= 0 || id >= NYRA_MAX_TASKS) {
        return NULL;
    }
    return g_tasks[id];
}

static int alloc_task(void) {
#if defined(_WIN32)
    table_lock_init();
#endif
    NyraTask *t = (NyraTask *)calloc(1, sizeof(NyraTask));
    if (!t) {
        return 0;
    }
    TASK_INIT(t);

#if defined(_WIN32)
    EnterCriticalSection(&g_table_cs);
#else
    pthread_mutex_lock(&g_table_mu);
#endif
    int id = g_next_task++;
    if (g_next_task >= NYRA_MAX_TASKS) {
        g_next_task = 1;
    }
    if (g_tasks[id]) {
        free(g_tasks[id]);
    }
    g_tasks[id] = t;
#if defined(_WIN32)
    LeaveCriticalSection(&g_table_cs);
#else
    pthread_mutex_unlock(&g_table_mu);
#endif
    return id;
}

int async_promise_new(void) {
    return alloc_task();
}

void async_promise_complete(int handle, int value) {
    NyraTask *t = task_get(handle);
    if (!t) {
        return;
    }
    TASK_LOCK(t);
    t->result = value;
    t->done = 1;
    TASK_SIGNAL(t);
    TASK_UNLOCK(t);
}

int async_await(int handle) {
    NyraTask *t = task_get(handle);
    if (!t) {
        return 0;
    }
    TASK_LOCK(t);
    TASK_WAIT(t);
    int r = t->result;
    TASK_UNLOCK(t);
    return r;
}

int async_poll(int handle) {
    NyraTask *t = task_get(handle);
    if (!t) {
        return -1;
    }
    TASK_LOCK(t);
    if (!t->done) {
        TASK_UNLOCK(t);
        return -1;
    }
    int r = t->result;
    TASK_UNLOCK(t);
    return r;
}

int async_run(int result) {
    int h = async_promise_new();
    if (h == 0) {
        return 0;
    }
    async_promise_complete(h, result);
    return h;
}

void runtime_run(void) {
    io_wait_once(0);
}

int io_register(int fd, int task_id) {
#ifdef __APPLE__
    IO_LOCK();
    if (g_kq < 0) {
        g_kq = kqueue();
    }
    struct kevent ev;
    EV_SET(&ev, (uintptr_t)fd, EVFILT_READ, EV_ADD, 0, 0, (void *)(intptr_t)task_id);
    int ok = kevent(g_kq, &ev, 1, NULL, 0, NULL) == 0 ? 0 : -1;
    IO_UNLOCK();
    return ok;
#elif defined(__linux__)
    IO_LOCK();
    if (g_epoll < 0) {
        g_epoll = epoll_create1(0);
    }
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.u32 = (uint32_t)task_id;
    int ok = epoll_ctl(g_epoll, EPOLL_CTL_ADD, fd, &ev) == 0 ? 0 : -1;
    IO_UNLOCK();
    return ok;
#elif defined(_WIN32)
    if (fd < 0 || task_id <= 0) {
        return -1;
    }
    nyra_winsock_ensure();
    io_lock_init();
    IO_LOCK();
    for (int i = 0; i < g_io_n; i++) {
        if (g_io_tab[i].fd == fd) {
            g_io_tab[i].task_id = task_id;
            g_io_tab[i].active = 1;
            IO_UNLOCK();
            return 0;
        }
    }
    if (g_io_n >= NYRA_MAX_IO) {
        IO_UNLOCK();
        return -1;
    }
    g_io_tab[g_io_n].fd = fd;
    g_io_tab[g_io_n].task_id = task_id;
    g_io_tab[g_io_n].active = 1;
    g_io_n++;
    IO_UNLOCK();
    return 0;
#else
    (void)fd;
    (void)task_id;
    return -1;
#endif
}

int io_wait_once(int timeout_ms) {
#ifdef __APPLE__
    if (g_kq < 0) {
        return 0;
    }
    struct kevent ev;
    struct timespec ts;
    ts.tv_sec = timeout_ms / 1000;
    ts.tv_nsec = (long)(timeout_ms % 1000) * 1000000L;
    int n = kevent(g_kq, NULL, 0, &ev, 1, timeout_ms > 0 ? &ts : NULL);
    if (n <= 0) {
        return 0;
    }
    int task_id = (int)(intptr_t)ev.udata;
    async_promise_complete(task_id, (int)ev.ident);
    return 1;
#elif defined(__linux__)
    if (g_epoll < 0) {
        return 0;
    }
    struct epoll_event ev;
    int n = epoll_wait(g_epoll, &ev, 1, timeout_ms);
    if (n <= 0) {
        return 0;
    }
    async_promise_complete((int)ev.data.u32, 1);
    return 1;
#elif defined(_WIN32)
    io_lock_init();
    IO_LOCK();
    fd_set rfds;
    FD_ZERO(&rfds);
    SOCKET max_sock = 0;
    int count = 0;
    for (int i = 0; i < g_io_n; i++) {
        if (g_io_tab[i].active) {
            FD_SET((SOCKET)g_io_tab[i].fd, &rfds);
            if ((SOCKET)g_io_tab[i].fd > max_sock) {
                max_sock = (SOCKET)g_io_tab[i].fd;
            }
            count++;
        }
    }
    IO_UNLOCK();
    if (count == 0) {
        return 0;
    }
    nyra_winsock_ensure();
    struct timeval tv;
    struct timeval *ptv = NULL;
    if (timeout_ms > 0) {
        tv.tv_sec = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        ptv = &tv;
    }
    int r = select((int)max_sock + 1, &rfds, NULL, NULL, ptv);
    if (r <= 0) {
        return 0;
    }
    IO_LOCK();
    for (int i = 0; i < g_io_n; i++) {
        if (g_io_tab[i].active && FD_ISSET((SOCKET)g_io_tab[i].fd, &rfds)) {
            int tid = g_io_tab[i].task_id;
            int ready_fd = g_io_tab[i].fd;
            g_io_tab[i].active = 0;
            IO_UNLOCK();
            async_promise_complete(tid, ready_fd);
            return 1;
        }
    }
    IO_UNLOCK();
    return 0;
#else
    (void)timeout_ms;
    return 0;
#endif
}

static void nyra_spawn_noop(void *data) {
    (void)data;
}

void spawn(void) {
    spawn_capture(nyra_spawn_noop, NULL, 0);
}
