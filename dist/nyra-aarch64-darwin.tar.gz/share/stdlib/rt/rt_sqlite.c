#include <sqlite3.h>
#include <stdlib.h>

int sqlite_exec(void *handle, const char *sql) {
    sqlite3 *db = (sqlite3 *)handle;
    if (!db || !sql) {
        return -1;
    }
    char *err = NULL;
    int rc = sqlite3_exec(db, sql, NULL, NULL, &err);
    if (err) {
        sqlite3_free(err);
    }
    return rc == SQLITE_OK ? 0 : rc;
}

void *sqlite_open(const char *path) {
    sqlite3 *db = NULL;
    if (!path || sqlite3_open(path, &db) != SQLITE_OK) {
        if (db) {
            sqlite3_close(db);
        }
        return NULL;
    }
    return db;
}

void sqlite_close(void *handle) {
    sqlite3 *db = (sqlite3 *)handle;
    if (db) {
        sqlite3_close(db);
    }
}
