#include <stdlib.h>
#include <string.h>

void bounds_assert_i32(int ok) {
    if (!ok) {
        abort();
    }
}

static int cmp_i32(const void *a, const void *b) {
    int ia = *(const int *)a;
    int ib = *(const int *)b;
    return (ia > ib) - (ia < ib);
}

static int cmp_f64(const void *a, const void *b) {
    double da = *(const double *)a;
    double db = *(const double *)b;
    return (da > db) - (da < db);
}

void array_i32_sort_copy(int *dst, const int *src, int n) {
    if (n <= 0 || !dst || !src) {
        return;
    }
    memcpy(dst, src, (size_t)n * sizeof(int));
    qsort(dst, (size_t)n, sizeof(int), cmp_i32);
}

void array_f64_sort_copy(double *dst, const double *src, int n) {
    if (n <= 0 || !dst || !src) {
        return;
    }
    memcpy(dst, src, (size_t)n * sizeof(double));
    qsort(dst, (size_t)n, sizeof(double), cmp_f64);
}
