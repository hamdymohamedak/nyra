#include <stdlib.h>
#include <string.h>

typedef struct {
    int elem_size;
    int len;
    int cap;
    void *data;
} NyraVec;

void *vec_i32_new(void) {
    NyraVec *v = (NyraVec *)calloc(1, sizeof(NyraVec));
    if (!v) {
        return NULL;
    }
    v->elem_size = (int)sizeof(int);
    v->cap = 8;
    v->data = malloc((size_t)v->cap * (size_t)v->elem_size);
    if (!v->data) {
        free(v);
        return NULL;
    }
    return v;
}

void vec_i32_push(void *handle, int value) {
    NyraVec *v = (NyraVec *)handle;
    if (!v) {
        return;
    }
    if (v->len >= v->cap) {
        int nc = v->cap * 2;
        void *nd = realloc(v->data, (size_t)nc * (size_t)v->elem_size);
        if (!nd) {
            return;
        }
        v->data = nd;
        v->cap = nc;
    }
    ((int *)v->data)[v->len++] = value;
}

int vec_i32_get(void *handle, int index) {
    NyraVec *v = (NyraVec *)handle;
    if (!v || index < 0 || index >= v->len) {
        return 0;
    }
    return ((int *)v->data)[index];
}

int vec_i32_len(void *handle) {
    NyraVec *v = (NyraVec *)handle;
    return v ? v->len : 0;
}

int vec_i32_pop(void *handle) {
    NyraVec *v = (NyraVec *)handle;
    if (!v || v->len <= 0) {
        return 0;
    }
    return ((int *)v->data)[--v->len];
}

void vec_i32_free(void *handle) {
    NyraVec *v = (NyraVec *)handle;
    if (!v) {
        return;
    }
    free(v->data);
    free(v);
}

static char *nyra_strdup(const char *s) {
    if (!s) {
        return NULL;
    }
    size_t n = strlen(s);
    char *out = (char *)malloc(n + 1);
    if (!out) {
        return NULL;
    }
    memcpy(out, s, n + 1);
    return out;
}

void *vec_str_new(void) {
    NyraVec *v = (NyraVec *)calloc(1, sizeof(NyraVec));
    if (!v) {
        return NULL;
    }
    v->elem_size = (int)sizeof(char *);
    v->cap = 4;
    v->data = malloc((size_t)v->cap * (size_t)v->elem_size);
    if (!v->data) {
        free(v);
        return NULL;
    }
    return v;
}

void vec_str_push(void *handle, const char *value) {
    NyraVec *v = (NyraVec *)handle;
    if (!v) {
        return;
    }
    if (v->len >= v->cap) {
        int nc = v->cap * 2;
        void *nd = realloc(v->data, (size_t)nc * (size_t)v->elem_size);
        if (!nd) {
            return;
        }
        v->data = nd;
        v->cap = nc;
    }
    ((char **)v->data)[v->len++] = nyra_strdup(value ? value : "");
}

const char *vec_str_get(void *handle, int index) {
    NyraVec *v = (NyraVec *)handle;
    if (!v || index < 0 || index >= v->len) {
        return "";
    }
    const char *s = ((char **)v->data)[index];
    return s ? s : "";
}

int vec_str_len(void *handle) {
    NyraVec *v = (NyraVec *)handle;
    return v ? v->len : 0;
}

void vec_str_free(void *handle) {
    NyraVec *v = (NyraVec *)handle;
    if (!v) {
        return;
    }
    for (int i = 0; i < v->len; i++) {
        free(((char **)v->data)[i]);
    }
    free(v->data);
    free(v);
}
