#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#if defined(__has_include)
#if __has_include(<openssl/ssl.h>)
#define NYRA_TLS_OPENSSL 1
#include <openssl/err.h>
#include <openssl/ssl.h>
#endif
#endif

#ifndef NYRA_TLS_OPENSSL
#define NYRA_TLS_OPENSSL 0
#endif

#define NYRA_TLS_MAX 32
#define NYRA_TLS_HANDLE_BASE 0x100000

typedef struct {
    int used;
    int plain_fd;
    SSL *ssl;
    SSL_CTX *ctx;
} NyraTlsSlot;

static NyraTlsSlot g_tls[NYRA_TLS_MAX];
static int g_tls_inited;

static void tls_init_once(void) {
    if (g_tls_inited) {
        return;
    }
#if NYRA_TLS_OPENSSL
    SSL_library_init();
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();
#endif
    g_tls_inited = 1;
}

static int tls_slot_alloc(int plain_fd, SSL *ssl, SSL_CTX *ctx) {
    for (int i = 0; i < NYRA_TLS_MAX; i++) {
        if (!g_tls[i].used) {
            g_tls[i].used = 1;
            g_tls[i].plain_fd = plain_fd;
            g_tls[i].ssl = ssl;
            g_tls[i].ctx = ctx;
            return NYRA_TLS_HANDLE_BASE + i;
        }
    }
    return -1;
}

static NyraTlsSlot *tls_slot_from_handle(int handle) {
    if (handle < NYRA_TLS_HANDLE_BASE) {
        return NULL;
    }
    int idx = handle - NYRA_TLS_HANDLE_BASE;
    if (idx < 0 || idx >= NYRA_TLS_MAX || !g_tls[idx].used) {
        return NULL;
    }
    return &g_tls[idx];
}

extern int rt_tcp_connect(const char *host, int port);
extern void rt_tcp_close(int fd);
extern int rt_tcp_listen(const char *host, int port);
extern int rt_tcp_accept(int listener_fd);

#define NYRA_TLS_LISTEN_MAX 8

typedef struct {
    int used;
    int plain_fd;
    SSL_CTX *ctx;
} NyraTlsListener;

static NyraTlsListener g_tls_listeners[NYRA_TLS_LISTEN_MAX];

int tls_available(void) {
    return NYRA_TLS_OPENSSL ? 1 : 0;
}

int rt_tls_connect(const char *host, int port) {
#if !NYRA_TLS_OPENSSL
    (void)host;
    (void)port;
    return -1;
#else
    tls_init_once();
    if (!host || port <= 0) {
        return -1;
    }
    int fd = rt_tcp_connect(host, port);
    if (fd < 0) {
        return -1;
    }
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    if (!ctx) {
        rt_tcp_close(fd);
        return -1;
    }
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
    SSL *ssl = SSL_new(ctx);
    if (!ssl) {
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
        return -1;
    }
    SSL_set_tlsext_host_name(ssl, host);
    SSL_set_fd(ssl, fd);
    if (SSL_connect(ssl) != 1) {
        SSL_free(ssl);
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
        return -1;
    }
    int handle = tls_slot_alloc(fd, ssl, ctx);
    if (handle < 0) {
        SSL_free(ssl);
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
    }
    return handle;
#endif
}

char *rt_tls_read(int handle, int max_bytes) {
#if !NYRA_TLS_OPENSSL
    (void)handle;
    (void)max_bytes;
    return NULL;
#else
    NyraTlsSlot *slot = tls_slot_from_handle(handle);
    if (!slot || max_bytes <= 0) {
        return NULL;
    }
    if (max_bytes > 1024 * 1024) {
        max_bytes = 1024 * 1024;
    }
    char *buf = (char *)malloc((size_t)max_bytes + 1);
    if (!buf) {
        return NULL;
    }
    int n = SSL_read(slot->ssl, buf, max_bytes);
    if (n <= 0) {
        free(buf);
        return NULL;
    }
    buf[n] = '\0';
    return buf;
#endif
}

int rt_tls_write_bytes(int handle, const char *data, int len) {
#if !NYRA_TLS_OPENSSL
    (void)handle;
    (void)data;
    (void)len;
    return -1;
#else
    NyraTlsSlot *slot = tls_slot_from_handle(handle);
    if (!slot || !data || len < 0) {
        return -1;
    }
    int n = SSL_write(slot->ssl, data, len);
    return (n == len) ? 0 : -1;
#endif
}

int rt_tls_write(int handle, const char *data) {
#if !NYRA_TLS_OPENSSL
    (void)handle;
    (void)data;
    return -1;
#else
    if (!data) {
        return -1;
    }
    return rt_tls_write_bytes(handle, data, (int)strlen(data));
#endif
}

int rt_tls_read_bytes(int handle, char *buf, int len) {
#if !NYRA_TLS_OPENSSL
    (void)handle;
    (void)buf;
    (void)len;
    return -1;
#else
    NyraTlsSlot *slot = tls_slot_from_handle(handle);
    if (!slot || !buf || len <= 0) {
        return -1;
    }
    int got = 0;
    while (got < len) {
        int n = SSL_read(slot->ssl, buf + got, len - got);
        if (n <= 0) {
            return -1;
        }
        got += n;
    }
    return 0;
#endif
}

void rt_tls_close(int handle) {
#if !NYRA_TLS_OPENSSL
    (void)handle;
    return;
#else
    NyraTlsSlot *slot = tls_slot_from_handle(handle);
    if (!slot) {
        return;
    }
    if (slot->ssl) {
        SSL_shutdown(slot->ssl);
        SSL_free(slot->ssl);
        slot->ssl = NULL;
    }
    if (slot->ctx) {
        SSL_CTX_free(slot->ctx);
        slot->ctx = NULL;
    }
    if (slot->plain_fd >= 0) {
        rt_tcp_close(slot->plain_fd);
        slot->plain_fd = -1;
    }
    slot->used = 0;
#endif
}

static int tls_listener_alloc(int plain_fd, SSL_CTX *ctx) {
    for (int i = 0; i < NYRA_TLS_LISTEN_MAX; i++) {
        if (!g_tls_listeners[i].used) {
            g_tls_listeners[i].used = 1;
            g_tls_listeners[i].plain_fd = plain_fd;
            g_tls_listeners[i].ctx = ctx;
            return 0x200000 + i;
        }
    }
    return -1;
}

static NyraTlsListener *tls_listener_from_handle(int handle) {
    if (handle < 0x200000) {
        return NULL;
    }
    int idx = handle - 0x200000;
    if (idx < 0 || idx >= NYRA_TLS_LISTEN_MAX || !g_tls_listeners[idx].used) {
        return NULL;
    }
    return &g_tls_listeners[idx];
}

int rt_tls_listen(const char *cert_pem_path, const char *key_pem_path, const char *host, int port) {
#if !NYRA_TLS_OPENSSL
    (void)cert_pem_path;
    (void)key_pem_path;
    (void)host;
    (void)port;
    return -1;
#else
    tls_init_once();
    if (!cert_pem_path || !key_pem_path) {
        return -1;
    }
    int fd = rt_tcp_listen(host, port);
    if (fd < 0) {
        return -1;
    }
    SSL_CTX *ctx = SSL_CTX_new(TLS_server_method());
    if (!ctx) {
        rt_tcp_close(fd);
        return -1;
    }
    if (SSL_CTX_use_certificate_file(ctx, cert_pem_path, SSL_FILETYPE_PEM) != 1) {
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
        return -1;
    }
    if (SSL_CTX_use_PrivateKey_file(ctx, key_pem_path, SSL_FILETYPE_PEM) != 1) {
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
        return -1;
    }
  if (SSL_CTX_check_private_key(ctx) != 1) {
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
        return -1;
    }
    int handle = tls_listener_alloc(fd, ctx);
    if (handle < 0) {
        SSL_CTX_free(ctx);
        rt_tcp_close(fd);
    }
    return handle;
#endif
}

int rt_tls_accept(int listener_handle) {
#if !NYRA_TLS_OPENSSL
    (void)listener_handle;
    return -1;
#else
    NyraTlsListener *ln = tls_listener_from_handle(listener_handle);
    if (!ln) {
        return -1;
    }
    int client_fd = rt_tcp_accept(ln->plain_fd);
    if (client_fd < 0) {
        return -1;
    }
    SSL *ssl = SSL_new(ln->ctx);
    if (!ssl) {
        rt_tcp_close(client_fd);
        return -1;
    }
    SSL_set_fd(ssl, client_fd);
    if (SSL_accept(ssl) != 1) {
        SSL_free(ssl);
        rt_tcp_close(client_fd);
        return -1;
    }
    int handle = tls_slot_alloc(client_fd, ssl, NULL);
    if (handle < 0) {
        SSL_free(ssl);
        rt_tcp_close(client_fd);
    }
    return handle;
#endif
}

void rt_tls_listener_close(int listener_handle) {
#if !NYRA_TLS_OPENSSL
    (void)listener_handle;
    return;
#else
    NyraTlsListener *ln = tls_listener_from_handle(listener_handle);
    if (!ln) {
        return;
    }
    if (ln->ctx) {
        SSL_CTX_free(ln->ctx);
        ln->ctx = NULL;
    }
    if (ln->plain_fd >= 0) {
        rt_tcp_close(ln->plain_fd);
        ln->plain_fd = -1;
    }
    ln->used = 0;
#endif
}
