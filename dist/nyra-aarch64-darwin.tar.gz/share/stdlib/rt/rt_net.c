#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

void nyra_winsock_ensure(void) {
    static int inited = 0;
    if (!inited) {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) == 0) {
            inited = 1;
        }
    }
}

static int nyra_sock_close(int fd) {
    if (fd < 0) {
        return 0;
    }
    return closesocket((SOCKET)fd) == 0 ? 0 : -1;
}

static int nyra_sock_set_nonblock(int fd) {
    if (fd < 0) {
        return -1;
    }
    u_long mode = 1;
    return ioctlsocket((SOCKET)fd, FIONBIO, &mode) == 0 ? 0 : -1;
}

#else
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/socket.h>

void nyra_winsock_ensure(void) {}

static int nyra_sock_close(int fd) {
    if (fd >= 0) {
        close(fd);
    }
    return 0;
}

static int nyra_sock_set_nonblock(int fd) {
    if (fd < 0) {
        return -1;
    }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) {
        return -1;
    }
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0 ? 0 : -1;
}

#endif

extern int async_promise_new(void);
extern void async_promise_complete(int handle, int value);

static int set_reuse(int fd) {
    int one = 1;
    return setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&one, sizeof(one));
}

static int host_is_passive(const char *host) {
    return host == NULL || host[0] == '\0' ||
           strcmp(host, "0.0.0.0") == 0 || strcmp(host, "::") == 0;
}

int rt_tcp_listen(const char *host, int port) {
#if defined(_WIN32)
    nyra_winsock_ensure();
#endif
    struct addrinfo hints;
    struct addrinfo *res = NULL;
    char portbuf[16];
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (host_is_passive(host)) {
        hints.ai_flags = AI_PASSIVE;
        host = NULL;
    }
    snprintf(portbuf, sizeof(portbuf), "%d", port);
    if (getaddrinfo(host, portbuf, &hints, &res) != 0 || !res) {
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = (int)socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) {
            continue;
        }
        set_reuse(fd);
        if (bind(fd, p->ai_addr, (int)p->ai_addrlen) == 0 &&
            listen(fd, SOMAXCONN) == 0) {
            break;
        }
        nyra_sock_close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}

int rt_tcp_accept(int listener_fd) {
    if (listener_fd < 0) {
        return -1;
    }
#if defined(_WIN32)
    nyra_winsock_ensure();
#endif
    return (int)accept(listener_fd, NULL, NULL);
}

typedef struct {
    int listener_fd;
    int task_id;
} AcceptJob;

#if defined(_WIN32)
static DWORD WINAPI accept_worker(LPVOID arg) {
    AcceptJob *job = (AcceptJob *)arg;
    int client = rt_tcp_accept(job->listener_fd);
    async_promise_complete(job->task_id, client);
    free(job);
    return 0;
}
#else
static void *accept_worker(void *arg) {
    AcceptJob *job = (AcceptJob *)arg;
    int client = rt_tcp_accept(job->listener_fd);
    async_promise_complete(job->task_id, client);
    free(job);
    return NULL;
}
#endif

int rt_tcp_accept_async(int listener_fd) {
    int task = async_promise_new();
    if (task <= 0) {
        return -1;
    }
    AcceptJob *job = (AcceptJob *)malloc(sizeof(AcceptJob));
    if (!job) {
        return -1;
    }
    job->listener_fd = listener_fd;
    job->task_id = task;
#if defined(_WIN32)
    HANDLE th = CreateThread(NULL, 0, accept_worker, job, 0, NULL);
    if (!th) {
        free(job);
        return -1;
    }
    CloseHandle(th);
#else
    pthread_t th;
    if (pthread_create(&th, NULL, accept_worker, job) != 0) {
        free(job);
        return -1;
    }
    pthread_detach(th);
#endif
    return task;
}

int rt_tcp_connect(const char *host, int port) {
#if defined(_WIN32)
    nyra_winsock_ensure();
#endif
    struct addrinfo hints;
    struct addrinfo *res = NULL;
    char portbuf[16];
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    snprintf(portbuf, sizeof(portbuf), "%d", port);
    if (getaddrinfo(host, portbuf, &hints, &res) != 0 || !res) {
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = (int)socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) {
            continue;
        }
        if (connect(fd, p->ai_addr, (int)p->ai_addrlen) == 0) {
            break;
        }
        nyra_sock_close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}

char *rt_tcp_read(int fd, int max_bytes) {
    if (fd < 0 || max_bytes <= 0) {
        return NULL;
    }
    if (max_bytes > 1024 * 1024) {
        max_bytes = 1024 * 1024;
    }
    char *buf = (char *)malloc((size_t)max_bytes + 1);
    if (!buf) {
        return NULL;
    }
#if defined(_WIN32)
    nyra_winsock_ensure();
    int n = recv(fd, buf, max_bytes, 0);
#else
    ssize_t n = recv(fd, buf, (size_t)max_bytes, 0);
#endif
    if (n <= 0) {
        free(buf);
        return NULL;
    }
    buf[n] = '\0';
    return buf;
}

int rt_tcp_write_bytes(int fd, const char *data, int len) {
    if (fd < 0 || !data || len < 0) {
        return -1;
    }
#if defined(_WIN32)
    nyra_winsock_ensure();
    int n = send(fd, data, len, 0);
    return (n == len) ? 0 : -1;
#else
    ssize_t n = send(fd, data, (size_t)len, 0);
    return (n == (ssize_t)len) ? 0 : -1;
#endif
}

int rt_tcp_read_bytes(int fd, char *buf, int len) {
    if (fd < 0 || !buf || len <= 0) {
        return -1;
    }
    int got = 0;
    while (got < len) {
#if defined(_WIN32)
        nyra_winsock_ensure();
        int n = recv(fd, buf + got, len - got, 0);
#else
        ssize_t n = recv(fd, buf + got, (size_t)(len - got), 0);
#endif
        if (n <= 0) {
            return -1;
        }
        got += (int)n;
    }
    return 0;
}

int rt_tcp_write(int fd, const char *data) {
    if (fd < 0 || !data) {
        return -1;
    }
    return rt_tcp_write_bytes(fd, data, (int)strlen(data));
}

void rt_tcp_close(int fd) {
    nyra_sock_close(fd);
}

int sys_set_nonblock(int fd) {
#if defined(_WIN32)
    nyra_winsock_ensure();
#endif
    return nyra_sock_set_nonblock(fd);
}

int sys_listen(const char *host, int port) {
    return rt_tcp_listen(host, port);
}

int sys_accept(int listener_fd) {
    return rt_tcp_accept(listener_fd);
}

int sys_connect(const char *host, int port) {
    return rt_tcp_connect(host, port);
}

char *sys_recv(int fd, int max_bytes) {
    return rt_tcp_read(fd, max_bytes);
}

int sys_send(int fd, const char *data) {
    return rt_tcp_write(fd, data);
}

void sys_close(int fd) {
    rt_tcp_close(fd);
}

int rt_udp_bind(const char *host, int port) {
#if defined(_WIN32)
    nyra_winsock_ensure();
#endif
    struct addrinfo hints;
    struct addrinfo *res = NULL;
    char portbuf[16];
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    if (host_is_passive(host)) {
        hints.ai_flags = AI_PASSIVE;
        host = NULL;
    }
    snprintf(portbuf, sizeof(portbuf), "%d", port);
    if (getaddrinfo(host, portbuf, &hints, &res) != 0 || !res) {
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = (int)socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) {
            continue;
        }
        set_reuse(fd);
        if (bind(fd, p->ai_addr, (int)p->ai_addrlen) == 0) {
            break;
        }
        nyra_sock_close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}

char *rt_udp_recv(int fd, int max_bytes) {
    if (fd < 0 || max_bytes <= 0) {
        return NULL;
    }
    if (max_bytes > 65536) {
        max_bytes = 65536;
    }
    char *buf = (char *)malloc((size_t)max_bytes + 1);
    if (!buf) {
        return NULL;
    }
#if defined(_WIN32)
    nyra_winsock_ensure();
    int n = recv(fd, buf, max_bytes, 0);
#else
    ssize_t n = recv(fd, buf, (size_t)max_bytes, 0);
#endif
    if (n <= 0) {
        free(buf);
        return NULL;
    }
    buf[n] = '\0';
    return buf;
}

int rt_udp_send(int fd, const char *host, int port, const char *data) {
    if (fd < 0 || !host || !data) {
        return -1;
    }
    struct addrinfo hints;
    struct addrinfo *res = NULL;
    char portbuf[16];
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    snprintf(portbuf, sizeof(portbuf), "%d", port);
    if (getaddrinfo(host, portbuf, &hints, &res) != 0 || !res) {
        return -1;
    }
    int ok = -1;
#if defined(_WIN32)
    nyra_winsock_ensure();
    int n = sendto(fd, data, (int)strlen(data), 0, res->ai_addr, (int)res->ai_addrlen);
    ok = (n >= 0) ? 0 : -1;
#else
    ssize_t n = sendto(fd, data, strlen(data), 0, res->ai_addr, res->ai_addrlen);
    ok = (n >= 0) ? 0 : -1;
#endif
    freeaddrinfo(res);
    return ok;
}

void rt_udp_close(int fd) {
    nyra_sock_close(fd);
}
