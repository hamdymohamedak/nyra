#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Minimal JSON string field extractor for {"key":"value"} objects. */
char *json_get_string(const char *json, const char *key) {
    if (!json || !key) {
        return NULL;
    }
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *k = strstr(json, pattern);
    if (!k) {
        return NULL;
    }
    const char *colon = strchr(k + strlen(pattern), ':');
    if (!colon) {
        return NULL;
    }
    const char *q = strchr(colon + 1, '"');
    if (!q) {
        return NULL;
    }
    q++;
    const char *end = strchr(q, '"');
    if (!end) {
        return NULL;
    }
    size_t len = (size_t)(end - q);
    char *out = (char *)malloc(len + 1);
    if (!out) {
        return NULL;
    }
    memcpy(out, q, len);
    out[len] = '\0';
    return out;
}

/* Parse a JSON number field after "key": (integer only, MVP). Returns -2147483648 if missing. */
int json_get_i32(const char *json, const char *key) {
    if (!json || !key) {
        return -2147483648;
    }
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char *k = strstr(json, pattern);
    if (!k) {
        return -2147483648;
    }
    const char *colon = strchr(k + strlen(pattern), ':');
    if (!colon) {
        return -2147483648;
    }
    const char *p = colon + 1;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    int sign = 1;
    if (*p == '-') {
        sign = -1;
        p++;
    }
    if (*p < '0' || *p > '9') {
        return -2147483648;
    }
    long long v = 0;
    while (*p >= '0' && *p <= '9') {
        v = v * 10 + (*p - '0');
        p++;
    }
    return (int)(v * sign);
}

extern int vec_str_len(void *handle);
extern const char *vec_str_get(void *handle, int index);
extern char *str_cat(const char *a, const char *b);

char *json_encode_object(void *keys_vec, void *values_vec) {
    if (!keys_vec || !values_vec) {
        return NULL;
    }
    int n = vec_str_len(keys_vec);
    if (n != vec_str_len(values_vec) || n < 0) {
        return NULL;
    }
    char *out = (char *)malloc(2);
    if (!out) {
        return NULL;
    }
    out[0] = '{';
    out[1] = '\0';
    for (int i = 0; i < n; i++) {
        const char *k = vec_str_get(keys_vec, i);
        const char *v = vec_str_get(values_vec, i);
        if (!k || !v) {
            free(out);
            return NULL;
        }
        if (i > 0) {
            char *tmp = str_cat(out, ",");
            free(out);
            out = tmp;
        }
        char *part = (char *)malloc(strlen(k) + strlen(v) + 6);
        if (!part) {
            free(out);
            return NULL;
        }
        snprintf(part, strlen(k) + strlen(v) + 6, "\"%s\":\"%s\"", k, v);
        char *tmp2 = str_cat(out, part);
        free(part);
        free(out);
        out = tmp2;
    }
    char *done = str_cat(out, "}");
    free(out);
    return done;
}
