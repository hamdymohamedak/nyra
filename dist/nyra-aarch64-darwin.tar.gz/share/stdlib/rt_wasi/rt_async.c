int async_promise_new(void) {
    return 0;
}

void async_promise_complete(int handle, int value) {
    (void)handle;
    (void)value;
}

int async_await(int handle) {
    (void)handle;
    return 0;
}

int async_poll(int handle) {
    (void)handle;
    return -1;
}

int async_run(int result) {
    return result;
}

void runtime_run(void) {}

int io_register(int fd, int task_id) {
    (void)fd;
    (void)task_id;
    return -1;
}

int io_wait_once(int timeout_ms) {
    (void)timeout_ms;
    return 0;
}

void spawn(void) {}
